# 🎓 MAKTAB AI - Enterprise-Grade Educational Platform

**MAKTAB AI** - bugun dunyoda eng quvvatli, professional va to'liq funktsiyalari bilan ishlaydigan bo'g'lanmagan ta'lim platformasi. Super admin, maktab rahbari, o'qituvchi va o'quvchi uchun barcha kerak bo'lgan funktsiyalar bilan.

## ✨ Asosiy Xususiyatlar

### 🎨 Frontend (React 19 + TypeScript + Tailwind CSS)
- **Animated Cascade Logo**: "MAKTAB AI" har bir harf alohida paydo bo'ladi
- **Neon RGB AI Text**: "AI" yozuvi RGB ranglarida doimiy jilolanadi
- **Liquid Glassmorphism**: Shaffof, professional UI design
- **Fully Responsive**: Mobile, tablet, desktop uchun moslashuvchan
- **Real-time Updates**: Server bilan tez-tez data almashinuvi

### 🔐 Backend (Node.js + Express + PostgreSQL + Prisma)
- **JWT Authentication**: Xavfsiz kirish tizimi
- **Role-Based Access Control**: 4 ta rol (Super Admin, School Admin, Teacher, Student)
- **Complete CRUD Operations**: Barcha entiteter uchun to'liq operatsiyalar
- **Database Integrity**: PostgreSQL bilan relational bazasi
- **Audit Logging**: Tizimda barcha harakatlarni muhrash
- **Error Handling**: Professional xato boshqaruvi

### 👥 Foydalanuvchi Rollari

#### Super Admin (akhmad / Suvonqulov2024)
✅ Yangi maktab yaratish, tahrirlash, o'chirish  
✅ Tizim bo'ylab barcha foydalanuvchilarni boshqarish  
✅ Global statistika va monitoring  
✅ Audit logs ko'rish  

#### School Admin (Maktab Direktori)
✅ O'qituvchilarni qo'shish (automatik login/parol)  
✅ Sinflar yaratish  
✅ O'quvchilarni sinfga taqsimlash  
✅ Davomat va reytingni monitoring qilish  
✅ Maktab statistikasini ko'rish  

#### Teacher (O'qituvchi)
✅ O'z sinfidagi o'quvchilarni ko'rish  
✅ Davomatni belgilash (Keldi, Kelmadi, Sababli)  
✅ Baholar berish  
✅ Sinf faolligini kuzatish  

#### Student (O'quvchi)
✅ Shaxsiy dashboard (XP, Master Level, Baholar)  
✅ AI Tutor - savollar va javoblar  
✅ Focus Zone (Pomodoro timer)  
✅ Leaderboard (Global reyting)  
✅ Career Prediction (Kelajak tahlili)  

## 🚀 Tez Orali Sozlash

### Talablar
- Node.js 18+ va npm
- PostgreSQL 12+
- Git

### Backend Sozlash

