import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "../types";
import { apiClient } from "../services/api";

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoggedIn: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(
    localStorage.getItem("token")
  );
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const verifyToken = async () => {
      if (token) {
        try {
          const response = await apiClient.get("/auth/verify");
          if (response.data.success) {
            setUser(response.data.data.user);
          } else {
            localStorage.removeItem("token");
            setToken(null);
          }
        } catch (error) {
          localStorage.removeItem("token");
          setToken(null);
        }
      }
      setIsLoading(false);
    };

    verifyToken();
  }, [token]);

  const login = async (username: string, password: string) => {
    try {
      const response = await apiClient.post("/auth/login", {
        username,
        password,
      });

      if (response.data.success) {
        const newToken = response.data.data.accessToken;
        const userData = response.data.data.user;

        localStorage.setItem("token", newToken);
        setToken(newToken);
        setUser(userData);
      } else {
        throw new Error(response.data.message);
      }
    } catch (error: any) {
      throw new Error(
        error.response?.data?.message || "Login failed"
      );
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoggedIn: !!token,
        login,
        logout,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};
