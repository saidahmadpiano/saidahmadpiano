import React, { useState, useEffect } from "react";
import { Navigation } from "../components/Navigation";
import { ContactSection } from "../components/ContactSection";
import { schoolAdminService } from "../services/schoolAdminService";
import { Plus, Trash2, Edit2 } from "lucide-react";

export const SchoolAdminDashboard: React.FC = () => {
  const [teachers, setTeachers] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showTeacherForm, setShowTeacherForm] = useState(false);
  const [showClassForm, setShowClassForm] = useState(false);
  const [teacherForm, setTeacherForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    subject: "",
    specialization: "",
  });
  const [classForm, setClassForm] = useState({
    name: "",
    grade: 1,
    teacherId: "",
    description: "",
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [teachersRes, classesRes, statsRes] = await Promise.all([
        schoolAdminService.getTeachers(),
        schoolAdminService.getClasses(),
        schoolAdminService.getStatistics(),
      ]);
      setTeachers(teachersRes.data.data);
      setClasses(classesRes.data.data);
      setStats(statsRes.data.data);
    } catch (error) {
      console.error("Failed to load data", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await schoolAdminService.createTeacher(teacherForm);
      setTeachers([response.data.teacher, ...teachers]);
      setShowTeacherForm(false);
      setTeacherForm({
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        subject: "",
        specialization: "",
      });
      alert(
        `Teacher created!\nUsername: ${response.data.credentials.username}\nPassword: ${response.data.credentials.password}`
      );
    } catch (error) {
      alert("Failed to create teacher");
    }
  };

  const handleCreateClass = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await schoolAdminService.createClass(classForm);
      setClasses([response.data.data, ...classes]);
      setShowClassForm(false);
      setClassForm({
        name: "",
        grade: 1,
        teacherId: "",
        description: "",
      });
      alert("Class created successfully!");
    } catch (error) {
      alert("Failed to create class");
    }
  };

  const handleDeleteTeacher = async (teacherId: string) => {
    if (confirm("Are you sure?")) {
      try {
        await schoolAdminService.deleteTeacher(teacherId);
        setTeachers(teachers.filter((t) => t.id !== teacherId));
        alert("Teacher deleted successfully!");
      } catch (error) {
        alert("Failed to delete teacher");
      }
    }
  };

  if (isLoading) {
    return (
      <div>
        <Navigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p>Loading dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navigation />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        {stats && (
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Teachers</p>
              <p className="text-3xl font-bold text-blue-400 mt-2">
                {stats.teachers}
              </p>
            </div>
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Classes</p>
              <p className="text-3xl font-bold text-green-400 mt-2">
                {stats.classes}
              </p>
            </div>
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Students</p>
              <p className="text-3xl font-bold text-purple-400 mt-2">
                {stats.students}
              </p>
            </div>
          </div>
        )}

        {/* Teachers Section */}
        <div className="glass p-6 rounded-xl mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Teachers</h2>
            <button
              onClick={() => setShowTeacherForm(!showTeacherForm)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition"
            >
              <Plus size={20} />
              Add Teacher
            </button>
          </div>

          {showTeacherForm && (
            <form
              onSubmit={handleCreateTeacher}
              className="mb-6 p-6 glass rounded-lg space-y-4"
            >
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="First Name"
                  value={teacherForm.firstName}
                  onChange={(e) =>
                    setTeacherForm({
                      ...teacherForm,
                      firstName: e.target.value,
                    })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="Last Name"
                  value={teacherForm.lastName}
                  onChange={(e) =>
                    setTeacherForm({
                      ...teacherForm,
                      lastName: e.target.value,
                    })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="email"
                  placeholder="Email"
                  value={teacherForm.email}
                  onChange={(e) =>
                    setTeacherForm({ ...teacherForm, email: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="tel"
                  placeholder="Phone"
                  value={teacherForm.phoneNumber}
                  onChange={(e) =>
                    setTeacherForm({
                      ...teacherForm,
                      phoneNumber: e.target.value,
                    })
                  }
                  className="px-4 py-2 glass rounded-lg"
                />
                <input
                  type="text"
                  placeholder="Subject"
                  value={teacherForm.subject}
                  onChange={(e) =>
                    setTeacherForm({ ...teacherForm, subject: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="Specialization"
                  value={teacherForm.specialization}
                  onChange={(e) =>
                    setTeacherForm({
                      ...teacherForm,
                      specialization: e.target.value,
                    })
                  }
                  className="px-4 py-2 glass rounded-lg"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition"
                >
                  Create Teacher
                </button>
                <button
                  type="button"
                  onClick={() => setShowTeacherForm(false)}
                  className="px-6 py-2 bg-slate-600 hover:bg-slate-700 rounded-lg transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          <div className="space-y-4">
            {teachers.map((teacher) => (
              <div
                key={teacher.id}
                className="p-4 glass-hover rounded-lg flex justify-between items-start"
              >
                <div>
                  <h3 className="font-bold">
                    {teacher.user.firstName} {teacher.user.lastName}
                  </h3>
                  <p className="text-sm text-slate-400">
                    {teacher.subject}
                    {teacher.specialization && ` • ${teacher.specialization}`}
                  </p>
                  <p className="text-sm text-slate-500">
                    {teacher.user.email}
                  </p>
                  <p className="text-sm text-slate-500">
                    📚 Classes: {teacher.classes?.length || 0}
                  </p>
                </div>
                <button
                  onClick={() => handleDeleteTeacher(teacher.id)}
                  className="p-2 hover:bg-red-900 text-red-400 rounded-lg transition"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Classes Section */}
        <div className="glass p-6 rounded-xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Classes</h2>
            <button
              onClick={() => setShowClassForm(!showClassForm)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition"
            >
              <Plus size={20} />
              Add Class
            </button>
          </div>

          {showClassForm && (
            <form
              onSubmit={handleCreateClass}
              className="mb-6 p-6 glass rounded-lg space-y-4"
            >
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Class Name"
                  value={classForm.name}
                  onChange={(e) =>
                    setClassForm({ ...classForm, name: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <select
                  value={classForm.grade}
                  onChange={(e) =>
                    setClassForm({
                      ...classForm,
                      grade: parseInt(e.target.value),
                    })
                  }
                  className="px-4 py-2 glass rounded-lg"
                >
                  {[...Array(11)].map((_, i) => (
                    <option key={i + 1} value={i + 1}>
                      Grade {i + 1}
                    </option>
                  ))}
                </select>
                <select
                  value={classForm.teacherId}
                  onChange={(e) =>
                    setClassForm({
                      ...classForm,
                      teacherId: e.target.value,
                    })
                  }
                  className="px-4 py-2 glass rounded-lg col-span-2"
                  required
                >
                  <option value="">Select Teacher</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.user.firstName} {t.user.lastName} ({t.subject})
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition"
                >
                  Create Class
                </button>
                <button
                  type="button"
                  onClick={() => setShowClassForm(false)}
                  className="px-6 py-2 bg-slate-600 hover:bg-slate-700 rounded-lg transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          <div className="space-y-4">
            {classes.map((cls) => (
              <div
                key={cls.id}
                className="p-4 glass-hover rounded-lg flex justify-between items-start"
              >
                <div>
                  <h3 className="font-bold">
                    {cls.name} • Grade {cls.grade}
                  </h3>
                  <p className="text-sm text-slate-400">
                    Teacher: {cls.teacher.user.firstName}{" "}
                    {cls.teacher.user.lastName}
                  </p>
                  <p className="text-sm text-slate-500">
                    👨‍🎓 Students: {cls.students?.length || 0}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <ContactSection />
      </div>
    </div>
  );
};
