import React, { useState, useEffect } from "react";
import { Navigation } from "../components/Navigation";
import { ContactSection } from "../components/ContactSection";
import { superAdminService } from "../services/superAdminService";
import { Plus, Trash2, Edit2, Search } from "lucide-react";

export const SuperAdminDashboard: React.FC = () => {
  const [schools, setSchools] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    type: "GENERAL",
    address: "",
    phoneNumber: "",
    principalName: "",
    districtName: "",
    regionName: "",
    description: "",
  });

  useEffect(() => {
    loadData();
  }, [searchTerm]);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [schoolsRes, statsRes] = await Promise.all([
        superAdminService.getSchools(1, 10, searchTerm),
        superAdminService.getStatistics(),
      ]);
      setSchools(schoolsRes.data.data);
      setStats(statsRes.data.data);
    } catch (error) {
      console.error("Failed to load data", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await superAdminService.createSchool(formData);
      setSchools([response.data.school, ...schools]);
      setShowForm(false);
      setFormData({
        name: "",
        type: "GENERAL",
        address: "",
        phoneNumber: "",
        principalName: "",
        districtName: "",
        regionName: "",
        description: "",
      });
      alert("School created successfully!");
    } catch (error) {
      alert("Failed to create school");
    }
  };

  const handleDeleteSchool = async (schoolId: string) => {
    if (confirm("Are you sure?")) {
      try {
        await superAdminService.deleteSchool(schoolId);
        setSchools(schools.filter((s) => s.id !== schoolId));
        alert("School deleted successfully!");
      } catch (error) {
        alert("Failed to delete school");
      }
    }
  };

  if (isLoading) {
    return (
      <div>
        <Navigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p>Loading dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navigation />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats */}
        {stats && (
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Schools</p>
              <p className="text-3xl font-bold text-blue-400 mt-2">
                {stats.totalSchools}
              </p>
            </div>
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Users</p>
              <p className="text-3xl font-bold text-green-400 mt-2">
                {stats.totalUsers}
              </p>
            </div>
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Teachers</p>
              <p className="text-3xl font-bold text-purple-400 mt-2">
                {stats.totalTeachers}
              </p>
            </div>
            <div className="glass p-6 rounded-xl">
              <p className="text-slate-400 text-sm">Total Students</p>
              <p className="text-3xl font-bold text-pink-400 mt-2">
                {stats.totalStudents}
              </p>
            </div>
          </div>
        )}

        {/* School Management */}
        <div className="glass p-6 rounded-xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Schools Management</h2>
            <button
              onClick={() => setShowForm(!showForm)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition"
            >
              <Plus size={20} />
              Add School
            </button>
          </div>

          {/* Search */}
          <div className="mb-6 flex items-center gap-2 p-3 glass rounded-lg">
            <Search size={20} className="text-slate-400" />
            <input
              type="text"
              placeholder="Search schools..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-transparent outline-none"
            />
          </div>

          {/* Create Form */}
          {showForm && (
            <form
              onSubmit={handleCreateSchool}
              className="mb-6 p-6 glass rounded-lg space-y-4"
            >
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="School Name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <select
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({ ...formData, type: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                >
                  <option value="GENERAL">General</option>
                  <option value="ART">Art</option>
                </select>
                <input
                  type="text"
                  placeholder="Principal Name"
                  value={formData.principalName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      principalName: e.target.value,
                    })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={formData.phoneNumber}
                  onChange={(e) =>
                    setFormData({ ...formData, phoneNumber: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="Address"
                  value={formData.address}
                  onChange={(e) =>
                    setFormData({ ...formData, address: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="District"
                  value={formData.districtName}
                  onChange={(e) =>
                    setFormData({ ...formData, districtName: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg"
                  required
                />
                <input
                  type="text"
                  placeholder="Region"
                  value={formData.regionName}
                  onChange={(e) =>
                    setFormData({ ...formData, regionName: e.target.value })
                  }
                  className="px-4 py-2 glass rounded-lg col-span-2"
                  required
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition"
                >
                  Create School
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-6 py-2 bg-slate-600 hover:bg-slate-700 rounded-lg transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Schools List */}
          <div className="space-y-4">
            {schools.map((school) => (
              <div
                key={school.id}
                className="p-4 glass-hover rounded-lg flex justify-between items-start"
              >
                <div className="flex-1">
                  <h3 className="font-bold text-lg">{school.name}</h3>
                  <p className="text-sm text-slate-400">
                    {school.type} • {school.principalName}
                  </p>
                  <p className="text-sm text-slate-500 mt-1">
                    📍 {school.address}
                  </p>
                  <p className="text-sm text-slate-500">
                    👨‍🏫 Teachers: {school.teachers?.length || 0} | 👨‍🎓
                    Students: {school.totalStudents}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-slate-700 rounded-lg transition">
                    <Edit2 size={18} />
                  </button>
                  <button
                    onClick={() => handleDeleteSchool(school.id)}
                    className="p-2 hover:bg-red-900 text-red-400 rounded-lg transition"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <ContactSection />
      </div>
    </div>
  );
};
