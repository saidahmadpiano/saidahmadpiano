import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/authContext";
import { AnimatedLogo } from "../components/AnimatedLogo";
import { LoadingSpinner } from "../components/LoadingSpinner";

export const Login: React.FC = () => {
  const [username, setUsername] = useState("akhmad");
  const [password, setPassword] = useState("Suvonqulov2024");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      await login(username, password);
      navigate("/");
    } catch (err: any) {
      setError(err.message || "Login failed");
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <LoadingSpinner message="Logging in..." />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="mb-8">
          <AnimatedLogo />
          <p className="text-center text-slate-400 mt-4">
            Enterprise-Grade Educational Platform
          </p>
        </div>

        <div className="glass p-8 rounded-2xl space-y-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">Welcome Back</h2>
            <p className="text-slate-400 text-sm">
              Sign in to your account to continue
            </p>
          </div>

          {error && (
            <div className="p-4 bg-red-900/20 border border-red-700 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-2 glass rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500"
                placeholder="Enter username"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 glass rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500"
                placeholder="Enter password"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-2 rounded-lg transition"
            >
              Sign In
            </button>
          </form>

          <div className="pt-4 border-t border-slate-700">
            <p className="text-xs text-slate-500 text-center">
              Demo Credentials: akhmad / Suvonqulov2024
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
