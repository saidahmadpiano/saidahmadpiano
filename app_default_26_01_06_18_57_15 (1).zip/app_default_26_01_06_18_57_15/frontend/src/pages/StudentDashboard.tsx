import React, { useState, useEffect } from "react";
import { Navigation } from "../components/Navigation";
import { ContactSection } from "../components/ContactSection";
import { studentService } from "../services/studentService";
import { Zap, Brain, Target, TrendingUp } from "lucide-react";

export const StudentDashboard: React.FC = () => {
  const [dashboard, setDashboard] = useState<any>(null);
  const [leaderboard, setLeaderboard] = useState<any>(null);
  const [prediction, setPrediction] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [focusMinutes, setFocusMinutes] = useState(0);
  const [aiQuestion, setAiQuestion] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [activeTab, setActiveTab] = useState("dashboard");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashRes, leaderRes, predRes] = await Promise.all([
        studentService.getDashboard(),
        studentService.getLeaderboard(),
        studentService.getPrediction(),
      ]);
      setDashboard(dashRes.data.data);
      setLeaderboard(leaderRes.data.data);
      setPrediction(predRes.data.data);
    } catch (error) {
      console.error("Failed to load data", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddFocusMinutes = async () => {
    if (focusMinutes > 0) {
      try {
        const response = await studentService.updateFocusMinutes(focusMinutes);
        setDashboard((prev: any) => ({
          ...prev,
          student: {
            ...prev.student,
            focusMinutes: response.data.data.focusMinutes,
            xp: response.data.data.xp,
            masterLevel: response.data.data.masterLevel,
          },
        }));
        setFocusMinutes(0);
        alert("Great! You earned some XP!");
      } catch (error) {
        alert("Failed to add focus minutes");
      }
    }
  };

  const handleAskTutor = async () => {
    if (aiQuestion.trim()) {
      try {
        const response = await studentService.askAiTutor(aiQuestion);
        setAiResponse(response.data.data.response);
        setAiQuestion("");
      } catch (error) {
        alert("Failed to get AI response");
      }
    }
  };

  if (isLoading) {
    return (
      <div>
        <Navigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p>Loading your dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navigation />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {dashboard && (
          <>
            {/* Header Stats */}
            <div className="grid md:grid-cols-4 gap-4 mb-8">
              <div className="glass p-6 rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Master Level</p>
                    <p className="text-3xl font-bold text-purple-400 mt-2">
                      {dashboard.student.masterLevel}
                    </p>
                  </div>
                  <Zap size={32} className="text-purple-400 opacity-50" />
                </div>
              </div>

              <div className="glass p-6 rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Total XP</p>
                    <p className="text-3xl font-bold text-blue-400 mt-2">
                      {dashboard.student.xp}
                    </p>
                  </div>
                  <Zap size={32} className="text-blue-400 opacity-50" />
                </div>
              </div>

              <div className="glass p-6 rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Average Grade</p>
                    <p className="text-3xl font-bold text-green-400 mt-2">
                      {dashboard.student.averageGrade.toFixed(1)}
                    </p>
                  </div>
                  <TrendingUp size={32} className="text-green-400 opacity-50" />
                </div>
              </div>

              <div className="glass p-6 rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm">Class Rank</p>
                    <p className="text-3xl font-bold text-pink-400 mt-2">
                      #{dashboard.studentRank}
                    </p>
                  </div>
                  <Target size={32} className="text-pink-400 opacity-50" />
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-4 mb-8 border-b border-slate-700">
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`pb-2 font-semibold transition ${
                  activeTab === "dashboard"
                    ? "border-b-2 border-blue-500 text-blue-400"
                    : "text-slate-400"
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab("leaderboard")}
                className={`pb-2 font-semibold transition ${
                  activeTab === "leaderboard"
                    ? "border-b-2 border-blue-500 text-blue-400"
                    : "text-slate-400"
                }`}
              >
                Leaderboard
              </button>
              <button
                onClick={() => setActiveTab("ai-tutor")}
                className={`pb-2 font-semibold transition ${
                  activeTab === "ai-tutor"
                    ? "border-b-2 border-blue-500 text-blue-400"
                    : "text-slate-400"
                }`}
              >
                <Brain size={18} className="inline mr-2" />
                AI Tutor
              </button>
              <button
                onClick={() => setActiveTab("career")}
                className={`pb-2 font-semibold transition ${
                  activeTab === "career"
                    ? "border-b-2 border-blue-500 text-blue-400"
                    : "text-slate-400"
                }`}
              >
                Career
              </button>
            </div>

            {/* Dashboard Tab */}
            {activeTab === "dashboard" && (
              <div className="grid md:grid-cols-2 gap-8">
                {/* Attendance */}
                <div className="glass p-6 rounded-xl">
                  <h3 className="text-xl font-bold mb-4">Attendance</h3>
                  <div className="space-y-2">
                    <p className="text-slate-400">
                      Total: <span className="text-white">{dashboard.attendance.total}</span>
                    </p>
                    <p className="text-green-400">
                      Present: <span className="text-white">{dashboard.attendance.present}</span>
                    </p>
                    <p className="text-red-400">
                      Absent: <span className="text-white">{dashboard.attendance.absent}</span>
                    </p>
                    <p className="text-yellow-400">
                      Excused: <span className="text-white">{dashboard.attendance.excused}</span>
                    </p>
                  </div>
                </div>

                {/* Focus Zone */}
                <div className="glass p-6 rounded-xl">
                  <h3 className="text-xl font-bold mb-4">Focus Zone</h3>
                  <div className="space-y-4">
                    <p className="text-slate-400">
                      Total Focus Minutes:{" "}
                      <span className="text-white font-bold">
                        {dashboard.student.focusMinutes}
                      </span>
                    </p>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={focusMinutes}
                        onChange={(e) => setFocusMinutes(parseInt(e.target.value))}
                        placeholder="Enter minutes"
                        className="flex-1 px-3 py-2 glass rounded-lg"
                      />
                      <button
                        onClick={handleAddFocusMinutes}
                        className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </div>

                {/* Recent Grades */}
                <div className="glass p-6 rounded-xl md:col-span-2">
                  <h3 className="text-xl font-bold mb-4">Recent Grades</h3>
                  <div className="space-y-3">
                    {dashboard.grades.map((grade: any, index: number) => (
                      <div
                        key={index}
                        className="p-3 glass-hover rounded-lg flex justify-between items-center"
                      >
                        <div>
                          <p className="font-semibold">{grade.subject}</p>
                          <p className="text-sm text-slate-400">
                            {grade.score}/{grade.score + (100 - grade.score)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-blue-400">
                            {grade.percentage.toFixed(0)}%
                          </p>
                          <p className="text-sm text-slate-400">
                            {grade.gradeLetter}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Leaderboard Tab */}
            {activeTab === "leaderboard" && (
              <div className="glass p-6 rounded-xl">
                <h3 className="text-xl font-bold mb-4">Class Leaderboard</h3>
                <div className="space-y-3">
                  {leaderboard.data.map((student: any) => (
                    <div
                      key={student.rank}
                      className={`p-4 glass-hover rounded-lg flex items-center gap-4 ${
                        student.rank === dashboard.studentRank
                          ? "border-2 border-blue-500"
                          : ""
                      }`}
                    >
                      <div className="text-2xl font-bold text-slate-400 w-12">
                        #{student.rank}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold">{student.studentName}</p>
                        <p className="text-sm text-slate-400">
                          Level {student.masterLevel} • {student.xp} XP
                        </p>
                      </div>
                      {student.rank === dashboard.studentRank && (
                        <span className="px-3 py-1 bg-blue-600 rounded-full text-sm">
                          You
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* AI Tutor Tab */}
            {activeTab === "ai-tutor" && (
              <div className="glass p-6 rounded-xl">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Brain size={24} />
                  AI Tutor
                </h3>
                <div className="space-y-4">
                  <p className="text-slate-400">
                    Ask me anything about your studies!
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={aiQuestion}
                      onChange={(e) => setAiQuestion(e.target.value)}
                      placeholder="Ask a question..."
                      className="flex-1 px-4 py-2 glass rounded-lg"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") handleAskTutor();
                      }}
                    />
                    <button
                      onClick={handleAskTutor}
                      className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition"
                    >
                      Ask
                    </button>
                  </div>
                  {aiResponse && (
                    <div className="p-4 glass-hover rounded-lg">
                      <p className="text-slate-300">{aiResponse}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Career Tab */}
            {activeTab === "career" && prediction && (
              <div className="glass p-6 rounded-xl">
                <h3 className="text-xl font-bold mb-4">Career Prediction</h3>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-700">
                    <p className="text-blue-200">{prediction.prediction}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3">Recommendations:</h4>
                    <ul className="space-y-2">
                      {prediction.recommendations.map(
                        (rec: string, idx: number) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="text-green-400 mt-1">✓</span>
                            <span>{rec}</span>
                          </li>
                        )
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        <ContactSection />
      </div>
    </div>
  );
};
