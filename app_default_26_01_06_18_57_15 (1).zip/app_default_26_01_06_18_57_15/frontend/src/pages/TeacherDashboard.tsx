import React, { useState, useEffect } from "react";
import { Navigation } from "../components/Navigation";
import { ContactSection } from "../components/ContactSection";
import { teacherService } from "../services/teacherService";

export const TeacherDashboard: React.FC = () => {
  const [classes, setClasses] = useState<any[]>([]);
  const [selectedClass, setSelectedClass] = useState<any>(null);
  const [students, setStudents] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("classes");
  const [attendanceForm, setAttendanceForm] = useState({
    studentId: "",
    date: new Date().toISOString().split("T")[0],
    status: "PRESENT",
    notes: "",
  });
  const [gradeForm, setGradeForm] = useState({
    studentId: "",
    subject: "",
    score: 0,
    maxScore: 100,
    notes: "",
  });

  useEffect(() => {
    loadClasses();
  }, []);

  const loadClasses = async () => {
    try {
      const response = await teacherService.getClasses();
      setClasses(response.data.data);
    } catch (error) {
      console.error("Failed to load classes", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectClass = async (cls: any) => {
    setSelectedClass(cls);
    try {
      const response = await teacherService.getClassStudents(cls.id);
      setStudents(response.data.data);
    } catch (error) {
      console.error("Failed to load students", error);
    }
  };

  const handleMarkAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClass) return;
    try {
      await teacherService.markAttendance(selectedClass.id, attendanceForm);
      alert("Attendance marked successfully!");
      setAttendanceForm({
        studentId: "",
        date: new Date().toISOString().split("T")[0],
        status: "PRESENT",
        notes: "",
      });
    } catch (error) {
      alert("Failed to mark attendance");
    }
  };

  const handleGiveGrade = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClass) return;
    try {
      await teacherService.giveGrade(selectedClass.id, gradeForm);
      alert("Grade given successfully!");
      setGradeForm({
        studentId: "",
        subject: "",
        score: 0,
        maxScore: 100,
        notes: "",
      });
    } catch (error) {
      alert("Failed to give grade");
    }
  };

  if (isLoading) {
    return (
      <div>
        <Navigation />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p>Loading dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navigation />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold mb-8">Teacher Dashboard</h1>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Classes List */}
          <div className="glass p-6 rounded-xl">
            <h2 className="text-xl font-bold mb-4">My Classes</h2>
            <div className="space-y-2">
              {classes.map((cls) => (
                <button
                  key={cls.id}
                  onClick={() => handleSelectClass(cls)}
                  className={`w-full p-3 text-left rounded-lg transition ${
                    selectedClass?.id === cls.id
                      ? "bg-blue-600"
                      : "glass-hover"
                  }`}
                >
                  <p className="font-semibold">{cls.name}</p>
                  <p className="text-sm text-slate-400">
                    Grade {cls.grade} • {cls.students?.length || 0} students
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-2">
            {selectedClass ? (
              <div className="glass p-6 rounded-xl space-y-6">
                <h2 className="text-2xl font-bold">{selectedClass.name}</h2>

                {/* Tabs */}
                <div className="flex gap-4 border-b border-slate-700">
                  <button
                    onClick={() => setActiveTab("students")}
                    className={`pb-2 font-semibold transition ${
                      activeTab === "students"
                        ? "border-b-2 border-blue-500 text-blue-400"
                        : "text-slate-400"
                    }`}
                  >
                    Students
                  </button>
                  <button
                    onClick={() => setActiveTab("attendance")}
                    className={`pb-2 font-semibold transition ${
                      activeTab === "attendance"
                        ? "border-b-2 border-blue-500 text-blue-400"
                        : "text-slate-400"
                    }`}
                  >
                    Attendance
                  </button>
                  <button
                    onClick={() => setActiveTab("grades")}
                    className={`pb-2 font-semibold transition ${
                      activeTab === "grades"
                        ? "border-b-2 border-blue-500 text-blue-400"
                        : "text-slate-400"
                    }`}
                  >
                    Grades
                  </button>
                </div>

                {/* Students Tab */}
                {activeTab === "students" && (
                  <div className="space-y-3">
                    {students.map((student) => (
                      <div
                        key={student.id}
                        className="p-3 glass-hover rounded-lg"
                      >
                        <p className="font-semibold">
                          {student.user.firstName} {student.user.lastName}
                        </p>
                        <p className="text-sm text-slate-400">
                          {student.user.email}
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Attendance Tab */}
                {activeTab === "attendance" && (
                  <form onSubmit={handleMarkAttendance} className="space-y-4">
                    <select
                      value={attendanceForm.studentId}
                      onChange={(e) =>
                        setAttendanceForm({
                          ...attendanceForm,
                          studentId: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 glass rounded-lg"
                      required
                    >
                      <option value="">Select Student</option>
                      {students.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.user.firstName} {s.user.lastName}
                        </option>
                      ))}
                    </select>

                    <input
                      type="date"
                      value={attendanceForm.date}
                      onChange={(e) =>
                        setAttendanceForm({
                          ...attendanceForm,
                          date: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 glass rounded-lg"
                    />

                    <select
                      value={attendanceForm.status}
                      onChange={(e) =>
                        setAttendanceForm({
                          ...attendanceForm,
                          status: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 glass rounded-lg"
                    >
                      <option value="PRESENT">Present</option>
                      <option value="ABSENT">Absent</option>
                      <option value="EXCUSED">Excused</option>
                    </select>

                    <button
                      type="submit"
                      className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition"
                    >
                      Mark Attendance
                    </button>
                  </form>
                )}

                {/* Grades Tab */}
                {activeTab === "grades" && (
                  <form onSubmit={handleGiveGrade} className="space-y-4">
                    <select
                      value={gradeForm.studentId}
                      onChange={(e) =>
                        setGradeForm({
                          ...gradeForm,
                          studentId: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 glass rounded-lg"
                      required
                    >
                      <option value="">Select Student</option>
                      {students.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.user.firstName} {s.user.lastName}
                        </option>
                      ))}
                    </select>

                    <input
                      type="text"
                      placeholder="Subject"
                      value={gradeForm.subject}
                      onChange={(e) =>
                        setGradeForm({
                          ...gradeForm,
                          subject: e.target.value,
                        })
                      }
                      className="w-full px-4 py-2 glass rounded-lg"
                      required
                    />

                    <input
                      type="number"
                      placeholder="Score"
                      value={gradeForm.score}
                      onChange={(e) =>
                        setGradeForm({
                          ...gradeForm,
                          score: parseFloat(e.target.value),
                        })
                      }
                      className="w-full px-4 py-2 glass rounded-lg"
                      required
                    />

                    <button
                      type="submit"
                      className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition"
                    >
                      Give Grade
                    </button>
                  </form>
                )}
              </div>
            ) : (
              <div className="glass p-6 rounded-xl text-center text-slate-400">
                Select a class to manage
              </div>
            )}
          </div>
        </div>

        <ContactSection />
      </div>
    </div>
  );
};
