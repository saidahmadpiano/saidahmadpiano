import { apiClient } from "./api";

export const authService = {
  login: async (username: string, password: string) => {
    const response = await apiClient.post("/auth/login", {
      username,
      password,
    });
    return response.data;
  },

  logout: async () => {
    const response = await apiClient.post("/auth/logout");
    return response.data;
  },

  verify: async () => {
    const response = await apiClient.get("/auth/verify");
    return response.data;
  },
};
