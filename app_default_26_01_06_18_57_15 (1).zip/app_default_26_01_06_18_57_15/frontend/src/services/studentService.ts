import { apiClient } from "./api";

export const studentService = {
  getDashboard: async () => {
    const response = await apiClient.get("/student/dashboard");
    return response.data;
  },

  getLeaderboard: async (page = 1, limit = 50) => {
    const response = await apiClient.get("/student/leaderboard", {
      params: { page, limit },
    });
    return response.data;
  },

  updateFocusMinutes: async (minutes: number) => {
    const response = await apiClient.post("/student/focus-minutes", {
      minutes,
    });
    return response.data;
  },

  askAiTutor: async (question: string) => {
    const response = await apiClient.post("/student/ai-tutor", { question });
    return response.data;
  },

  recordSnapSolve: async (imagePath: string) => {
    const response = await apiClient.post("/student/snap-solve", { imagePath });
    return response.data;
  },

  getPrediction: async () => {
    const response = await apiClient.get("/student/career-prediction");
    return response.data;
  },
};
