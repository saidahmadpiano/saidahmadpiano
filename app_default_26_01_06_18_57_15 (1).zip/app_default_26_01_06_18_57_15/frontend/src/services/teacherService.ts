import { apiClient } from "./api";

export const teacherService = {
  getClasses: async () => {
    const response = await apiClient.get("/teacher/classes");
    return response.data;
  },

  getClassStudents: async (classId: string) => {
    const response = await apiClient.get(
      `/teacher/classes/${classId}/students`
    );
    return response.data;
  },

  markAttendance: async (classId: string, attendanceData: any) => {
    const response = await apiClient.post(
      `/teacher/classes/${classId}/attendance`,
      attendanceData
    );
    return response.data;
  },

  getClassAttendance: async (classId: string) => {
    const response = await apiClient.get(
      `/teacher/classes/${classId}/attendance`
    );
    return response.data;
  },

  giveGrade: async (classId: string, gradeData: any) => {
    const response = await apiClient.post(
      `/teacher/classes/${classId}/grades`,
      gradeData
    );
    return response.data;
  },

  getClassGrades: async (classId: string) => {
    const response = await apiClient.get(`/teacher/classes/${classId}/grades`);
    return response.data;
  },
};
