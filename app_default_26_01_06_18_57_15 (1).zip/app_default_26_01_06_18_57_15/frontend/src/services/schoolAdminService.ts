import { apiClient } from "./api";

export const schoolAdminService = {
  createTeacher: async (teacherData: any) => {
    const response = await apiClient.post("/school-admin/teachers", teacherData);
    return response.data;
  },

  getTeachers: async () => {
    const response = await apiClient.get("/school-admin/teachers");
    return response.data;
  },

  updateTeacher: async (teacherId: string, data: any) => {
    const response = await apiClient.put(
      `/school-admin/teachers/${teacherId}`,
      data
    );
    return response.data;
  },

  deleteTeacher: async (teacherId: string) => {
    const response = await apiClient.delete(
      `/school-admin/teachers/${teacherId}`
    );
    return response.data;
  },

  createClass: async (classData: any) => {
    const response = await apiClient.post("/school-admin/classes", classData);
    return response.data;
  },

  getClasses: async () => {
    const response = await apiClient.get("/school-admin/classes");
    return response.data;
  },

  addStudentToClass: async (studentId: string, classId: string) => {
    const response = await apiClient.post("/school-admin/classes/add-student", {
      studentId,
      classId,
    });
    return response.data;
  },

  getStatistics: async () => {
    const response = await apiClient.get("/school-admin/statistics");
    return response.data;
  },
};
