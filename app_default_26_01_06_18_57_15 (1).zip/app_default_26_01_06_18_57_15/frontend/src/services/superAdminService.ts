import { apiClient } from "./api";

export const superAdminService = {
  createSchool: async (schoolData: any) => {
    const response = await apiClient.post("/super-admin/schools", schoolData);
    return response.data;
  },

  getSchools: async (page = 1, limit = 10, search = "") => {
    const response = await apiClient.get("/super-admin/schools", {
      params: { page, limit, search },
    });
    return response.data;
  },

  getSchoolById: async (schoolId: string) => {
    const response = await apiClient.get(`/super-admin/schools/${schoolId}`);
    return response.data;
  },

  updateSchool: async (schoolId: string, data: any) => {
    const response = await apiClient.put(
      `/super-admin/schools/${schoolId}`,
      data
    );
    return response.data;
  },

  deleteSchool: async (schoolId: string) => {
    const response = await apiClient.delete(`/super-admin/schools/${schoolId}`);
    return response.data;
  },

  getUsers: async (page = 1, limit = 10) => {
    const response = await apiClient.get("/super-admin/users", {
      params: { page, limit },
    });
    return response.data;
  },

  getStatistics: async () => {
    const response = await apiClient.get("/super-admin/statistics");
    return response.data;
  },

  getAuditLogs: async (page = 1, limit = 50) => {
    const response = await apiClient.get("/super-admin/audit-logs", {
      params: { page, limit },
    });
    return response.data;
  },
};
