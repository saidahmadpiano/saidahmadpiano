export interface User {
  id: string;
  email: string;
  username: string;
  firstName: string;
  lastName: string;
  role: "SUPER_ADMIN" | "SCHOOL_ADMIN" | "TEACHER" | "STUDENT";
  schoolId?: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isLoggedIn: boolean;
}

export interface School {
  id: string;
  name: string;
  type: "ART" | "GENERAL";
  address: string;
  phoneNumber: string;
  principalName: string;
  districtName: string;
  regionName: string;
  totalStudents: number;
  totalTeachers: number;
  totalClasses: number;
  createdAt: string;
}

export interface Teacher {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  subject: string;
  specialization?: string;
}

export interface StudentData {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  xp: number;
  masterLevel: number;
  averageGrade: number;
  presentDays: number;
  focusMinutes: number;
}

export interface Class {
  id: string;
  name: string;
  grade: number;
  teacherName: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  statusCode: number;
  message: string;
  data?: T;
  error?: string;
  timestamp: string;
}
