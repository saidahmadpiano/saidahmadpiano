import React, { useEffect, useState } from "react";

export const AnimatedLogo: React.FC = () => {
  const [visibleLetters, setVisibleLetters] = useState(0);

  useEffect(() => {
    const letters = "MAKTAB AI".length;
    let current = 0;

    const interval = setInterval(() => {
      current += 1;
      if (current <= letters) {
        setVisibleLetters(current);
      } else {
        clearInterval(interval);
      }
    }, 150);

    return () => clearInterval(interval);
  }, []);

  const text = "MAKTAB AI";

  return (
    <div className="flex items-center justify-center gap-1">
      <h1 className="text-5xl font-black tracking-wider">
        {text.split("").map((letter, index) => (
          <span
            key={index}
            className={`inline-block transition-all duration-500 ${
              index < visibleLetters
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-4"
            }`}
            style={{
              animation:
                index < visibleLetters
                  ? `cascade 0.5s ease-out forwards`
                  : "none",
            }}
          >
            {letter === " " ? "\u00A0" : letter}
          </span>
        ))}
      </h1>
      <div className="text-3xl font-black animate-neon ml-2">AI</div>
    </div>
  );
};
