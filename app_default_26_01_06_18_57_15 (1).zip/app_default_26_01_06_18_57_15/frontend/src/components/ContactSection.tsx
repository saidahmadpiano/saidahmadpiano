import React from "react";
import { MessageCircle, Mail, Phone, Github } from "lucide-react";

export const ContactSection: React.FC = () => {
  return (
    <div className="mt-12 p-6 glass rounded-xl border border-slate-700">
      <h3 className="text-lg font-bold mb-4 text-blue-400">
        📞 Founder & Support
      </h3>
      <div className="grid md:grid-cols-2 gap-4">
        <a
          href="https://t.me/akhmly"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 p-3 glass-hover rounded-lg"
        >
          <MessageCircle className="text-blue-500" size={24} />
          <div>
            <p className="text-sm text-slate-400">Telegram</p>
            <p className="font-semibold">@akhmly</p>
          </div>
        </a>

        <a
          href="https://instagram.com/akhmad.developer"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 p-3 glass-hover rounded-lg"
        >
          <Github className="text-pink-500" size={24} />
          <div>
            <p className="text-sm text-slate-400">Instagram</p>
            <p className="font-semibold">@akhmad.developer</p>
          </div>
        </a>

        <a
          href="tel:+998993327308"
          className="flex items-center gap-3 p-3 glass-hover rounded-lg"
        >
          <Phone className="text-green-500" size={24} />
          <div>
            <p className="text-sm text-slate-400">Phone</p>
            <p className="font-semibold">+998 99 332 73 08</p>
          </div>
        </a>

        <div className="flex items-center gap-3 p-3 glass-hover rounded-lg">
          <Mail className="text-yellow-500" size={24} />
          <div>
            <p className="text-sm text-slate-400">Founder</p>
            <p className="font-semibold">Saidahmad Suvonqulov</p>
          </div>
        </div>
      </div>
    </div>
  );
};
