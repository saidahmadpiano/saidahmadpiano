/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#3B82F6",
        secondary: "#1E293B",
        accent: "#F97316",
      },
      animation: {
        cascade: "cascade 1.5s ease-out forwards",
        neon: "neon 2s ease-in-out infinite",
        pulse: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        float: "float 3s ease-in-out infinite",
      },
      keyframes: {
        cascade: {
          "0%": {
            opacity: "0",
            transform: "translateY(-20px)",
          },
          "100%": {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
        neon: {
          "0%, 100%": {
            color: "#ff0000",
            textShadow: "0 0 10px #ff0000",
          },
          "33%": {
            color: "#00ff00",
            textShadow: "0 0 10px #00ff00",
          },
          "66%": {
            color: "#0000ff",
            textShadow: "0 0 10px #0000ff",
          },
        },
        float: {
          "0%, 100%": {
            transform: "translateY(0px)",
          },
          "50%": {
            transform: "translateY(-20px)",
          },
        },
      },
      backdropFilter: {
        none: "none",
        sm: "blur(4px)",
        DEFAULT: "blur(12px)",
        md: "blur(16px)",
        lg: "blur(20px)",
        xl: "blur(24px)",
      },
    },
  },
  plugins: [],
};
