export interface JwtPayload {
  id: string;
  email: string;
  username: string;
  role: string;
  schoolId?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  statusCode: number;
  message: string;
  data?: T;
  error?: string;
  timestamp: string;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  search?: string;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface CreateSchoolDto {
  name: string;
  type: "ART" | "GENERAL";
  address: string;
  phoneNumber: string;
  principalName: string;
  districtName: string;
  regionName: string;
  description?: string;
}

export interface UpdateSchoolDto extends Partial<CreateSchoolDto> {}

export interface CreateTeacherDto {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string;
  subject: string;
  specialization?: string;
}

export interface CreateStudentDto {
  firstName: string;
  lastName: string;
  email: string;
  classId: string;
  parentPhone?: string;
  parentName?: string;
}

export interface CreateAttendanceDto {
  studentId: string;
  date: Date;
  status: "PRESENT" | "ABSENT" | "EXCUSED";
  notes?: string;
}

export interface CreateGradeDto {
  studentId: string;
  subject: string;
  score: number;
  maxScore?: number;
  notes?: string;
}

export interface CreateClassDto {
  name: string;
  grade: number;
  teacherId: string;
  description?: string;
}

export interface AuthLoginDto {
  username: string;
  password: string;
}

export interface AuthTokenResponse {
  accessToken: string;
  user: {
    id: string;
    email: string;
    username: string;
    firstName: string;
    lastName: string;
    role: string;
    schoolId?: string;
  };
}
