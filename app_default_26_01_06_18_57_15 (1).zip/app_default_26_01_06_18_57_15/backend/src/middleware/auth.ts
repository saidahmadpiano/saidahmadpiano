import { Request, Response, NextFunction } from "express";
import { verifyToken } from "../utils/jwt";
import { UnauthorizedError } from "../utils/errors";

declare global {
  namespace Express {
    interface Request {
      user?: any;
      token?: string;
    }
  }
}

export const authMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new UnauthorizedError("Missing or invalid authorization header");
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      throw new UnauthorizedError("Invalid or expired token");
    }

    req.user = payload;
    req.token = token;
    next();
  } catch (error) {
    if (error instanceof UnauthorizedError) {
      return res
        .status(401)
        .json({ success: false, message: error.message, statusCode: 401 });
    }
    return res
      .status(401)
      .json({ success: false, message: "Unauthorized", statusCode: 401 });
  }
};

export const optionalAuthMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      const payload = verifyToken(token);
      if (payload) {
        req.user = payload;
        req.token = token;
      }
    }
    next();
  } catch (error) {
    next();
  }
};
