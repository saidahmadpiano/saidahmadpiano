import { Request, Response, NextFunction } from "express";
import { ApiError } from "../utils/errors";
import { sendError } from "../utils/response";

export const errorHandler = (
  err: Error | ApiError,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error("Error:", err);

  if (err instanceof ApiError) {
    return sendError(res, err.statusCode, err.message, err.error);
  }

  if (err instanceof SyntaxError) {
    return sendError(res, 400, "Invalid JSON");
  }

  return sendError(res, 500, "Internal server error", err.message);
};
