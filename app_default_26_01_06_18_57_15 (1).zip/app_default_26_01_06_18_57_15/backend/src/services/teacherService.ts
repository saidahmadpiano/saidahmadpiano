import prisma from "../config/database";
import { CreateAttendanceDto, CreateGradeDto } from "../types";
import { NotFoundError, BadRequestError } from "../utils/errors";

export class TeacherService {
  async markAttendance(
    dto: CreateAttendanceDto,
    teacherId: string,
    classId: string
  ): Promise<any> {
    const teacher = await prisma.teacher.findUnique({
      where: { id: teacherId },
    });

    if (!teacher) {
      throw new NotFoundError("Teacher not found");
    }

    const student = await prisma.student.findUnique({
      where: { id: dto.studentId },
    });

    if (!student || student.classId !== classId) {
      throw new NotFoundError("Student not found in this class");
    }

    const schoolClass = await prisma.schoolClass.findUnique({
      where: { id: classId },
    });

    if (!schoolClass) {
      throw new NotFoundError("Class not found");
    }

    const attendance = await prisma.attendance.upsert({
      where: {
        studentId_classId_date: {
          studentId: dto.studentId,
          classId,
          date: new Date(dto.date),
        },
      },
      update: {
        status: dto.status,
        notes: dto.notes,
      },
      create: {
        studentId: dto.studentId,
        classId,
        teacherId,
        date: new Date(dto.date),
        status: dto.status,
        notes: dto.notes,
      },
    });

    if (dto.status === "PRESENT") {
      await prisma.student.update({
        where: { id: dto.studentId },
        data: { presentDays: { increment: 1 } },
      });
    }

    return attendance;
  }

  async giveGrade(
    dto: CreateGradeDto,
    teacherId: string,
    classId: string
  ): Promise<any> {
    const teacher = await prisma.teacher.findUnique({
      where: { id: teacherId },
    });

    if (!teacher) {
      throw new NotFoundError("Teacher not found");
    }

    const student = await prisma.student.findUnique({
      where: { id: dto.studentId },
    });

    if (!student || student.classId !== classId) {
      throw new NotFoundError("Student not found in this class");
    }

    if (dto.score < 0 || dto.score > (dto.maxScore || 100)) {
      throw new BadRequestError("Invalid score");
    }

    const percentage = (dto.score / (dto.maxScore || 100)) * 100;
    let gradeLetter = "F";
    if (percentage >= 90) gradeLetter = "A";
    else if (percentage >= 80) gradeLetter = "B";
    else if (percentage >= 70) gradeLetter = "C";
    else if (percentage >= 60) gradeLetter = "D";

    const grade = await prisma.grade.create({
      data: {
        studentId: dto.studentId,
        classId,
        teacherId,
        subject: dto.subject,
        score: dto.score,
        maxScore: dto.maxScore || 100,
        percentage,
        gradeLetter,
        notes: dto.notes,
      },
    });

    const allGrades = await prisma.grade.findMany({
      where: { studentId: dto.studentId },
    });

    const avgGrade =
      allGrades.reduce((sum, g) => sum + g.percentage, 0) / allGrades.length;

    await prisma.student.update({
      where: { id: dto.studentId },
      data: {
        averageGrade: avgGrade,
        xp: { increment: Math.floor(percentage / 10) * 10 },
      },
    });

    return grade;
  }

  async getClassStudents(classId: string, teacherId: string): Promise<any[]> {
    const teacher = await prisma.teacher.findUnique({
      where: { id: teacherId },
    });

    if (!teacher) {
      throw new NotFoundError("Teacher not found");
    }

    const schoolClass = await prisma.schoolClass.findUnique({
      where: { id: classId },
    });

    if (!schoolClass || schoolClass.teacherId !== teacherId) {
      throw new NotFoundError("Class not found");
    }

    return prisma.student.findMany({
      where: { classId },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
          },
        },
      },
    });
  }

  async getClassAttendance(classId: string, teacherId: string): Promise<any[]> {
    const schoolClass = await prisma.schoolClass.findUnique({
      where: { id: classId },
    });

    if (!schoolClass || schoolClass.teacherId !== teacherId) {
      throw new NotFoundError("Class not found");
    }

    return prisma.attendance.findMany({
      where: { classId },
      include: {
        student: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
          },
        },
      },
      orderBy: { date: "desc" },
    });
  }

  async getClassGrades(classId: string, teacherId: string): Promise<any[]> {
    const schoolClass = await prisma.schoolClass.findUnique({
      where: { id: classId },
    });

    if (!schoolClass || schoolClass.teacherId !== teacherId) {
      throw new NotFoundError("Class not found");
    }

    return prisma.grade.findMany({
      where: { classId },
      include: {
        student: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
          },
        },
      },
      orderBy: { date: "desc" },
    });
  }

  async getTeacherClasses(teacherId: string): Promise<any[]> {
    return prisma.schoolClass.findMany({
      where: { teacherId },
      include: {
        teacher: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
          },
        },
        students: true,
      },
    });
  }
}

export const teacherService = new TeacherService();
