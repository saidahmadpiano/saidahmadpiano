import prisma from "../config/database";
import { NotFoundError } from "../utils/errors";

export class StudentService {
  async getDashboard(studentId: string): Promise<any> {
    const student = await prisma.student.findUnique({
      where: { id: studentId },
      include: {
        user: true,
        class: {
          include: {
            teacher: {
              include: {
                user: {
                  select: {
                    firstName: true,
                    lastName: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!student) {
      throw new NotFoundError("Student not found");
    }

    const grades = await prisma.grade.findMany({
      where: { studentId },
      orderBy: { date: "desc" },
      take: 5,
    });

    const attendance = await prisma.attendance.findMany({
      where: { studentId },
      orderBy: { date: "desc" },
    });

    const classStudents = await prisma.student.findMany({
      where: { classId: student.classId },
      orderBy: { xp: "desc" },
      take: 10,
    });

    const studentRank = classStudents.findIndex((s) => s.id === studentId) + 1;

    return {
      student: {
        id: student.id,
        firstName: student.user.firstName,
        lastName: student.user.lastName,
        email: student.user.email,
        xp: student.xp,
        masterLevel: student.masterLevel,
        averageGrade: student.averageGrade,
        presentDays: student.presentDays,
        focusMinutes: student.focusMinutes,
      },
      class: {
        id: student.class.id,
        name: student.class.name,
        grade: student.class.grade,
        teacher: `${student.class.teacher.user.firstName} ${student.class.teacher.user.lastName}`,
      },
      grades: grades.map((g) => ({
        subject: g.subject,
        score: g.score,
        percentage: g.percentage,
        gradeLetter: g.gradeLetter,
        date: g.date,
      })),
      attendance: {
        total: attendance.length,
        present: attendance.filter((a) => a.status === "PRESENT").length,
        absent: attendance.filter((a) => a.status === "ABSENT").length,
        excused: attendance.filter((a) => a.status === "EXCUSED").length,
      },
      leaderboard: classStudents.map((s, index) => ({
        rank: index + 1,
        studentName: `${s.user?.firstName} ${s.user?.lastName}`,
        xp: s.xp,
        masterLevel: s.masterLevel,
      })),
      studentRank,
    };
  }

  async getLeaderboard(
    schoolId: string,
    page = 1,
    limit = 50
  ): Promise<any> {
    const skip = (page - 1) * limit;

    const students = await prisma.student.findMany({
      where: { schoolId },
      orderBy: [{ masterLevel: "desc" }, { xp: "desc" }],
      skip,
      take: limit,
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
        class: {
          select: {
            name: true,
          },
        },
      },
    });

    const total = await prisma.student.count({ where: { schoolId } });

    return {
      data: students.map((s, index) => ({
        rank: skip + index + 1,
        studentName: `${s.user.firstName} ${s.user.lastName}`,
        className: s.class.name,
        masterLevel: s.masterLevel,
        xp: s.xp,
        averageGrade: s.averageGrade,
      })),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async updateFocusMinutes(studentId: string, minutes: number): Promise<any> {
    const student = await prisma.student.findUnique({
      where: { id: studentId },
    });

    if (!student) {
      throw new NotFoundError("Student not found");
    }

    const xpReward = Math.floor(minutes / 10);

    const updatedStudent = await prisma.student.update({
      where: { id: studentId },
      data: {
        focusMinutes: { increment: minutes },
        xp: { increment: xpReward },
        masterLevel: {
          set: Math.floor((student.xp + xpReward) / 1000) + 1,
        },
      },
    });

    return updatedStudent;
  }

  async getAiTutorResponse(question: string): Promise<string> {
    // Placeholder for AI integration (Gemini API can be integrated here)
    const responses: { [key: string]: string } = {
      math: "Matematika muammosini hal qilish uchun avvalambor masalani diqqat bilan o'qing.",
      science:
        "Fanlar dunyosida bilik kengaytirish uchun har kuni o'qishni davom ettirilg.",
      english:
        "Ingliz tiliga o'rganish uchun kuniga hech bo'lmaganda 30 daqiqa vaqt ajrating.",
    };

    const keyword = question.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
      if (keyword.includes(key)) {
        return response;
      }
    }

    return "Sizning savolingiz ohuning uchun men sizga yordamni taqdim qila olaman. Iltimos savolingizni yana tiklang.";
  }

  async recordSnapSolve(
    studentId: string,
    imagePath: string
  ): Promise<any> {
    // Placeholder for image analysis (OCR can be integrated here)
    const student = await prisma.student.findUnique({
      where: { id: studentId },
    });

    if (!student) {
      throw new NotFoundError("Student not found");
    }

    await prisma.student.update({
      where: { id: studentId },
      data: { xp: { increment: 50 } },
    });

    return {
      success: true,
      message: "Rasm tahlil qilindi va XP olindi",
      xpEarned: 50,
    };
  }

  async predictCareer(studentId: string): Promise<any> {
    const student = await prisma.student.findUnique({
      where: { id: studentId },
      include: {
        grades: true,
      },
    });

    if (!student) {
      throw new NotFoundError("Student not found");
    }

    const avgScore = student.averageGrade;
    let prediction = "";

    if (avgScore >= 85) {
      prediction =
        "Davomat va texnologiya sohasiga o'tish sizga juda mos kelar edi";
    } else if (avgScore >= 75) {
      prediction = "Tabiiy fanlar va muhandislik sizning kuchliq tomoniga xos";
    } else if (avgScore >= 65) {
      prediction = "Biznesi va boshqaruv sohasida turi yaxshi natija berishingiz mumkin";
    } else {
      prediction =
        "Ijtimoiy fanlardan foydalanib o'z yo'lingizni topishga o'rinib ko'ring";
    }

    return {
      studentName: `${student.user?.firstName} ${student.user?.lastName}`,
      averageGrade: student.averageGrade,
      masterLevel: student.masterLevel,
      prediction,
      recommendations: [
        "Kuniga hech bo'lmaganda 2 soat o'qishga vaqt ajrating",
        "Qiyin mavzularni o'qituvchidan so'rashlang",
        "Sinfdoshlari bilan hamkorlik qiling",
      ],
    };
  }
}

export const studentService = new StudentService();
