import prisma from "../config/database";
import { CreateTeacherDto, CreateStudentDto, CreateClassDto } from "../types";
import { hashPassword, generateRandomPassword } from "../utils/password";
import { ConflictError, NotFoundError, BadRequestError } from "../utils/errors";

export class SchoolAdminService {
  async createTeacher(
    dto: CreateTeacherDto,
    schoolId: string,
    adminId: string
  ): Promise<any> {
    const existingUser = await prisma.user.findUnique({
      where: { email: dto.email },
    });

    if (existingUser) {
      throw new ConflictError("Email already exists");
    }

    const username = dto.email.split("@")[0] + "-" + Math.random().toString(36).slice(2, 8);
    const password = generateRandomPassword();
    const passwordHash = await hashPassword(password);

    const user = await prisma.user.create({
      data: {
        firstName: dto.firstName,
        lastName: dto.lastName,
        email: dto.email,
        username,
        passwordHash,
        phoneNumber: dto.phoneNumber,
        role: "TEACHER",
        schoolId,
        isActive: true,
      },
    });

    const teacher = await prisma.teacher.create({
      data: {
        userId: user.id,
        schoolId,
        subject: dto.subject,
        specialization: dto.specialization,
      },
    });

    await this.createAuditLog(
      adminId,
      schoolId,
      "CREATE_TEACHER",
      "Teacher",
      teacher.id,
      JSON.stringify(teacher)
    );

    return {
      teacher: {
        id: teacher.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        subject: teacher.subject,
        specialization: teacher.specialization,
      },
      credentials: {
        username,
        password,
        email: user.email,
      },
    };
  }

  async updateTeacher(
    teacherId: string,
    dto: Partial<CreateTeacherDto>,
    schoolId: string,
    adminId: string
  ): Promise<any> {
    const teacher = await prisma.teacher.findUnique({
      where: { id: teacherId },
      include: { user: true },
    });

    if (!teacher || teacher.schoolId !== schoolId) {
      throw new NotFoundError("Teacher not found");
    }

    const updatedTeacher = await prisma.teacher.update({
      where: { id: teacherId },
      data: {
        subject: dto.subject,
        specialization: dto.specialization,
        user: {
          update: {
            firstName: dto.firstName,
            lastName: dto.lastName,
            phoneNumber: dto.phoneNumber,
          },
        },
      },
      include: { user: true },
    });

    await this.createAuditLog(
      adminId,
      schoolId,
      "UPDATE_TEACHER",
      "Teacher",
      teacherId,
      JSON.stringify(updatedTeacher)
    );

    return updatedTeacher;
  }

  async deleteTeacher(
    teacherId: string,
    schoolId: string,
    adminId: string
  ): Promise<any> {
    const teacher = await prisma.teacher.findUnique({
      where: { id: teacherId },
    });

    if (!teacher || teacher.schoolId !== schoolId) {
      throw new NotFoundError("Teacher not found");
    }

    const classCount = await prisma.schoolClass.count({
      where: { teacherId },
    });

    if (classCount > 0) {
      throw new BadRequestError(
        "Cannot delete teacher with assigned classes. Reassign classes first."
      );
    }

    await prisma.teacher.delete({ where: { id: teacherId } });

    await this.createAuditLog(
      adminId,
      schoolId,
      "DELETE_TEACHER",
      "Teacher",
      teacherId,
      JSON.stringify(teacher)
    );

    return { message: "Teacher deleted successfully" };
  }

  async createClass(
    dto: CreateClassDto,
    schoolId: string,
    adminId: string
  ): Promise<any> {
    const teacher = await prisma.teacher.findUnique({
      where: { id: dto.teacherId },
    });

    if (!teacher || teacher.schoolId !== schoolId) {
      throw new NotFoundError("Teacher not found");
    }

    const existingClass = await prisma.schoolClass.findFirst({
      where: {
        schoolId,
        name: dto.name,
      },
    });

    if (existingClass) {
      throw new ConflictError("Class already exists in this school");
    }

    const schoolClass = await prisma.schoolClass.create({
      data: {
        schoolId,
        name: dto.name,
        grade: dto.grade,
        teacherId: dto.teacherId,
        description: dto.description,
      },
    });

    await this.createAuditLog(
      adminId,
      schoolId,
      "CREATE_CLASS",
      "Class",
      schoolClass.id,
      JSON.stringify(schoolClass)
    );

    return schoolClass;
  }

  async addStudentToClass(
    studentId: string,
    classId: string,
    schoolId: string,
    adminId: string
  ): Promise<any> {
    const schoolClass = await prisma.schoolClass.findUnique({
      where: { id: classId },
    });

    if (!schoolClass || schoolClass.schoolId !== schoolId) {
      throw new NotFoundError("Class not found");
    }

    const student = await prisma.student.findUnique({
      where: { id: studentId },
    });

    if (!student || student.schoolId !== schoolId) {
      throw new NotFoundError("Student not found");
    }

    const updatedStudent = await prisma.student.update({
      where: { id: studentId },
      data: { classId },
    });

    await this.createAuditLog(
      adminId,
      schoolId,
      "ADD_STUDENT_TO_CLASS",
      "Student",
      studentId,
      JSON.stringify(student),
      JSON.stringify(updatedStudent)
    );

    return updatedStudent;
  }

  async getTeachers(schoolId: string): Promise<any[]> {
    return prisma.teacher.findMany({
      where: { schoolId },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
            phoneNumber: true,
          },
        },
        classes: true,
      },
    });
  }

  async getClasses(schoolId: string): Promise<any[]> {
    return prisma.schoolClass.findMany({
      where: { schoolId },
      include: {
        teacher: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true,
              },
            },
          },
        },
        students: true,
      },
    });
  }

  async getStatistics(schoolId: string): Promise<any> {
    const [teachers, classes, students] = await Promise.all([
      prisma.teacher.count({ where: { schoolId } }),
      prisma.schoolClass.count({ where: { schoolId } }),
      prisma.student.count({ where: { schoolId } }),
    ]);

    return {
      teachers,
      classes,
      students,
    };
  }

  private async createAuditLog(
    userId: string,
    schoolId: string,
    action: string,
    resourceType: string,
    resourceId: string,
    newValues: string
  ): Promise<void> {
    await prisma.auditLog.create({
      data: {
        userId,
        schoolId,
        action,
        resourceType,
        resourceId,
        newValues,
      },
    });
  }
}

export const schoolAdminService = new SchoolAdminService();
