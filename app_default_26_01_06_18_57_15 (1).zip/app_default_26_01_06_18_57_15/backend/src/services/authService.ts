import prisma from "../config/database";
import { AuthLoginDto, AuthTokenResponse } from "../types";
import { hashPassword, comparePassword } from "../utils/password";
import { generateToken } from "../utils/jwt";
import { UnauthorizedError, NotFoundError, BadRequestError } from "../utils/errors";

export class AuthService {
  async login(dto: AuthLoginDto): Promise<AuthTokenResponse> {
    const user = await prisma.user.findUnique({
      where: { username: dto.username },
    });

    if (!user) {
      throw new UnauthorizedError("Invalid username or password");
    }

    if (!user.isActive) {
      throw new UnauthorizedError("User account is inactive");
    }

    const isPasswordValid = await comparePassword(dto.password, user.passwordHash);
    if (!isPasswordValid) {
      throw new UnauthorizedError("Invalid username or password");
    }

    const token = generateToken({
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      schoolId: user.schoolId || undefined,
    });

    return {
      accessToken: token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        schoolId: user.schoolId || undefined,
      },
    };
  }

  async verifyToken(token: string) {
    const user = await prisma.user.findUnique({
      where: { id: token },
    });

    if (!user || !user.isActive) {
      throw new UnauthorizedError("User not found or inactive");
    }

    return user;
  }

  async logout(userId: string) {
    return { message: "Logged out successfully" };
  }
}

export const authService = new AuthService();
