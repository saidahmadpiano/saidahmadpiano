import prisma from "../config/database";
import { CreateSchoolDto, UpdateSchoolDto, PaginatedResponse } from "../types";
import { hashPassword, generateRandomPassword } from "../utils/password";
import { validateEmail } from "../utils/validation";
import { ConflictError, NotFoundError, BadRequestError } from "../utils/errors";
import { v4 as uuidv4 } from "uuid";

export class SuperAdminService {
  async createSchool(
    dto: CreateSchoolDto,
    superAdminId: string
  ): Promise<any> {
    const adminEmail = `admin-${uuidv4().slice(0, 8)}@maktab-ai.local`;
    const adminUsername = `admin-${uuidv4().slice(0, 8)}`;
    const adminPassword = generateRandomPassword();

    const passwordHash = await hashPassword(adminPassword);

    const admin = await prisma.user.create({
      data: {
        firstName: dto.principalName.split(" ")[0],
        lastName: dto.principalName.split(" ")[1] || "",
        email: adminEmail,
        username: adminUsername,
        passwordHash,
        phoneNumber: dto.phoneNumber,
        role: "SCHOOL_ADMIN",
        isActive: true,
      },
    });

    const school = await prisma.school.create({
      data: {
        name: dto.name,
        type: dto.type,
        address: dto.address,
        phoneNumber: dto.phoneNumber,
        principalName: dto.principalName,
        districtName: dto.districtName,
        regionName: dto.regionName,
        description: dto.description,
        adminId: admin.id,
      },
    });

    await prisma.user.update({
      where: { id: admin.id },
      data: { schoolId: school.id },
    });

    await this.createAuditLog(
      superAdminId,
      school.id,
      "CREATE_SCHOOL",
      "School",
      school.id,
      null,
      JSON.stringify(school)
    );

    return {
      school,
      admin: {
        username: adminUsername,
        password: adminPassword,
        email: adminEmail,
      },
    };
  }

  async updateSchool(
    schoolId: string,
    dto: UpdateSchoolDto,
    superAdminId: string
  ): Promise<any> {
    const school = await prisma.school.findUnique({
      where: { id: schoolId },
    });

    if (!school) {
      throw new NotFoundError("School not found");
    }

    const oldValues = JSON.stringify(school);

    const updatedSchool = await prisma.school.update({
      where: { id: schoolId },
      data: dto,
    });

    await this.createAuditLog(
      superAdminId,
      schoolId,
      "UPDATE_SCHOOL",
      "School",
      schoolId,
      oldValues,
      JSON.stringify(updatedSchool)
    );

    return updatedSchool;
  }

  async deleteSchool(schoolId: string, superAdminId: string): Promise<any> {
    const school = await prisma.school.findUnique({
      where: { id: schoolId },
    });

    if (!school) {
      throw new NotFoundError("School not found");
    }

    const oldValues = JSON.stringify(school);

    await prisma.school.delete({
      where: { id: schoolId },
    });

    await this.createAuditLog(
      superAdminId,
      schoolId,
      "DELETE_SCHOOL",
      "School",
      schoolId,
      oldValues,
      null
    );

    return { message: "School deleted successfully" };
  }

  async getAllSchools(
    page = 1,
    limit = 10,
    search?: string
  ): Promise<PaginatedResponse<any>> {
    const skip = (page - 1) * limit;

    let where: any = {};
    if (search) {
      where = {
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { principalName: { contains: search, mode: "insensitive" } },
          { address: { contains: search, mode: "insensitive" } },
        ],
      };
    }

    const schools = await prisma.school.findMany({
      where,
      skip,
      take: limit,
      include: {
        admin: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
            phoneNumber: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    const total = await prisma.school.count({ where });

    return {
      data: schools,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async getSchoolById(schoolId: string): Promise<any> {
    const school = await prisma.school.findUnique({
      where: { id: schoolId },
      include: {
        admin: {
          select: {
            firstName: true,
            lastName: true,
            email: true,
            phoneNumber: true,
          },
        },
        teachers: { select: { id: true } },
        classes: { select: { id: true } },
      },
    });

    if (!school) {
      throw new NotFoundError("School not found");
    }

    return {
      ...school,
      totalTeachers: school.teachers.length,
      totalClasses: school.classes.length,
    };
  }

  async getAllUsers(page = 1, limit = 10): Promise<PaginatedResponse<any>> {
    const skip = (page - 1) * limit;

    const users = await prisma.user.findMany({
      skip,
      take: limit,
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        username: true,
        role: true,
        isActive: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
    });

    const total = await prisma.user.count();

    return {
      data: users,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  async getStatistics(): Promise<any> {
    const [totalSchools, totalUsers, totalTeachers, totalStudents] =
      await Promise.all([
        prisma.school.count(),
        prisma.user.count(),
        prisma.teacher.count(),
        prisma.student.count(),
      ]);

    return {
      totalSchools,
      totalUsers,
      totalTeachers,
      totalStudents,
    };
  }

  async getAuditLogs(page = 1, limit = 50): Promise<PaginatedResponse<any>> {
    const skip = (page - 1) * limit;

    const logs = await prisma.auditLog.findMany({
      skip,
      take: limit,
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            role: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    const total = await prisma.auditLog.count();

    return {
      data: logs,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  private async createAuditLog(
    userId: string,
    schoolId: string,
    action: string,
    resourceType: string,
    resourceId: string,
    oldValues: string | null,
    newValues: string | null
  ): Promise<void> {
    await prisma.auditLog.create({
      data: {
        userId,
        schoolId,
        action,
        resourceType,
        resourceId,
        oldValues,
        newValues,
      },
    });
  }
}

export const superAdminService = new SuperAdminService();
