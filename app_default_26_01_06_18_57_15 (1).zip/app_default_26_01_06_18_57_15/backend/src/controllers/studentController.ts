import { Request, Response, NextFunction } from "express";
import { studentService } from "../services/studentService";
import { sendSuccess, sendError } from "../utils/response";
import prisma from "../config/database";

export class StudentController {
  async getDashboard(req: Request, res: Response, next: NextFunction) {
    try {
      const student = await prisma.student.findUnique({
        where: { userId: req.user.id },
      });

      if (!student) {
        return sendError(res, 403, "Student not found");
      }

      const result = await studentService.getDashboard(student.id);
      return sendSuccess(res, 200, "Dashboard retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getLeaderboard(req: Request, res: Response, next: NextFunction) {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;

      const student = await prisma.student.findUnique({
        where: { userId: req.user.id },
      });

      if (!student) {
        return sendError(res, 403, "Student not found");
      }

      const result = await studentService.getLeaderboard(
        student.schoolId,
        page,
        limit
      );
      return sendSuccess(res, 200, "Leaderboard retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async updateFocusMinutes(req: Request, res: Response, next: NextFunction) {
    try {
      const { minutes } = req.body;

      if (!minutes || minutes <= 0) {
        return sendError(res, 400, "Invalid minutes value");
      }

      const student = await prisma.student.findUnique({
        where: { userId: req.user.id },
      });

      if (!student) {
        return sendError(res, 403, "Student not found");
      }

      const result = await studentService.updateFocusMinutes(
        student.id,
        minutes
      );
      return sendSuccess(res, 200, "Focus minutes updated successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getAiTutorResponse(req: Request, res: Response, next: NextFunction) {
    try {
      const { question } = req.body;

      if (!question) {
        return sendError(res, 400, "Question is required");
      }

      const result = await studentService.getAiTutorResponse(question);
      return sendSuccess(
        res,
        200,
        "AI response generated successfully",
        { response: result }
      );
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async recordSnapSolve(req: Request, res: Response, next: NextFunction) {
    try {
      const { imagePath } = req.body;

      if (!imagePath) {
        return sendError(res, 400, "Image path is required");
      }

      const student = await prisma.student.findUnique({
        where: { userId: req.user.id },
      });

      if (!student) {
        return sendError(res, 403, "Student not found");
      }

      const result = await studentService.recordSnapSolve(
        student.id,
        imagePath
      );
      return sendSuccess(res, 201, "Snap solve recorded successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async predictCareer(req: Request, res: Response, next: NextFunction) {
    try {
      const student = await prisma.student.findUnique({
        where: { userId: req.user.id },
        include: { user: true },
      });

      if (!student) {
        return sendError(res, 403, "Student not found");
      }

      const result = await studentService.predictCareer(student.id);
      return sendSuccess(res, 200, "Career prediction retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }
}

export const studentController = new StudentController();
