import { Request, Response, NextFunction } from "express";
import { superAdminService } from "../services/superAdminService";
import { sendSuccess, sendError } from "../utils/response";
import { CreateSchoolDto } from "../types";

export class SuperAdminController {
  async createSchool(req: Request, res: Response, next: NextFunction) {
    try {
      const dto: CreateSchoolDto = req.body;

      if (
        !dto.name ||
        !dto.type ||
        !dto.address ||
        !dto.phoneNumber ||
        !dto.principalName ||
        !dto.districtName ||
        !dto.regionName
      ) {
        return sendError(res, 400, "Missing required fields");
      }

      const result = await superAdminService.createSchool(
        dto,
        req.user.id
      );
      return sendSuccess(res, 201, "School created successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async updateSchool(req: Request, res: Response, next: NextFunction) {
    try {
      const { schoolId } = req.params;
      const dto = req.body;

      const result = await superAdminService.updateSchool(
        schoolId,
        dto,
        req.user.id
      );
      return sendSuccess(res, 200, "School updated successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async deleteSchool(req: Request, res: Response, next: NextFunction) {
    try {
      const { schoolId } = req.params;

      const result = await superAdminService.deleteSchool(
        schoolId,
        req.user.id
      );
      return sendSuccess(res, 200, "School deleted successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getAllSchools(req: Request, res: Response, next: NextFunction) {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const search = req.query.search as string;

      const result = await superAdminService.getAllSchools(
        page,
        limit,
        search
      );
      return sendSuccess(res, 200, "Schools retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getSchoolById(req: Request, res: Response, next: NextFunction) {
    try {
      const { schoolId } = req.params;

      const result = await superAdminService.getSchoolById(schoolId);
      return sendSuccess(res, 200, "School retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getAllUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;

      const result = await superAdminService.getAllUsers(page, limit);
      return sendSuccess(res, 200, "Users retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getStatistics(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await superAdminService.getStatistics();
      return sendSuccess(res, 200, "Statistics retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getAuditLogs(req: Request, res: Response, next: NextFunction) {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 50;

      const result = await superAdminService.getAuditLogs(page, limit);
      return sendSuccess(res, 200, "Audit logs retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }
}

export const superAdminController = new SuperAdminController();
