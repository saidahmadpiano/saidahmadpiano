import { Request, Response, NextFunction } from "express";
import { authService } from "../services/authService";
import { sendSuccess, sendError } from "../utils/response";
import { AuthLoginDto, BadRequestError } from "../types";

export class AuthController {
  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const dto: AuthLoginDto = req.body;

      if (!dto.username || !dto.password) {
        return sendError(res, 400, "Username and password are required");
      }

      const result = await authService.login(dto);
      return sendSuccess(res, 200, "Login successful", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 401, error.message);
    }
  }

  async verifyToken(req: Request, res: Response, next: NextFunction) {
    try {
      if (!req.user) {
        return sendError(res, 401, "Unauthorized");
      }

      return sendSuccess(res, 200, "Token is valid", { user: req.user });
    } catch (error: any) {
      return sendError(res, 401, error.message);
    }
  }

  async logout(req: Request, res: Response, next: NextFunction) {
    try {
      return sendSuccess(res, 200, "Logout successful");
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }
}

export const authController = new AuthController();
