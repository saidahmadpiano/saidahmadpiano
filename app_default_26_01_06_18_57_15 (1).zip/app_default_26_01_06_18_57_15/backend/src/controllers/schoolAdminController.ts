import { Request, Response, NextFunction } from "express";
import { schoolAdminService } from "../services/schoolAdminService";
import { sendSuccess, sendError } from "../utils/response";
import { CreateTeacherDto, CreateStudentDto, CreateClassDto } from "../types";

export class SchoolAdminController {
  async createTeacher(req: Request, res: Response, next: NextFunction) {
    try {
      const dto: CreateTeacherDto = req.body;

      if (!dto.firstName || !dto.lastName || !dto.email || !dto.subject) {
        return sendError(res, 400, "Missing required fields");
      }

      const result = await schoolAdminService.createTeacher(
        dto,
        req.user.schoolId,
        req.user.id
      );
      return sendSuccess(res, 201, "Teacher created successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async updateTeacher(req: Request, res: Response, next: NextFunction) {
    try {
      const { teacherId } = req.params;
      const dto = req.body;

      const result = await schoolAdminService.updateTeacher(
        teacherId,
        dto,
        req.user.schoolId,
        req.user.id
      );
      return sendSuccess(res, 200, "Teacher updated successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async deleteTeacher(req: Request, res: Response, next: NextFunction) {
    try {
      const { teacherId } = req.params;

      const result = await schoolAdminService.deleteTeacher(
        teacherId,
        req.user.schoolId,
        req.user.id
      );
      return sendSuccess(res, 200, "Teacher deleted successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async createClass(req: Request, res: Response, next: NextFunction) {
    try {
      const dto: CreateClassDto = req.body;

      if (!dto.name || !dto.grade || !dto.teacherId) {
        return sendError(res, 400, "Missing required fields");
      }

      const result = await schoolAdminService.createClass(
        dto,
        req.user.schoolId,
        req.user.id
      );
      return sendSuccess(res, 201, "Class created successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async addStudentToClass(req: Request, res: Response, next: NextFunction) {
    try {
      const { studentId, classId } = req.body;

      if (!studentId || !classId) {
        return sendError(res, 400, "Missing required fields");
      }

      const result = await schoolAdminService.addStudentToClass(
        studentId,
        classId,
        req.user.schoolId,
        req.user.id
      );
      return sendSuccess(
        res,
        200,
        "Student added to class successfully",
        result
      );
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getTeachers(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await schoolAdminService.getTeachers(req.user.schoolId);
      return sendSuccess(res, 200, "Teachers retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getClasses(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await schoolAdminService.getClasses(req.user.schoolId);
      return sendSuccess(res, 200, "Classes retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getStatistics(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await schoolAdminService.getStatistics(
        req.user.schoolId
      );
      return sendSuccess(
        res,
        200,
        "Statistics retrieved successfully",
        result
      );
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }
}

export const schoolAdminController = new SchoolAdminController();
