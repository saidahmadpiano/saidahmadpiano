import { Request, Response, NextFunction } from "express";
import { teacherService } from "../services/teacherService";
import { sendSuccess, sendError } from "../utils/response";
import { CreateAttendanceDto, CreateGradeDto } from "../types";
import prisma from "../config/database";

export class TeacherController {
  async markAttendance(req: Request, res: Response, next: NextFunction) {
    try {
      const { classId } = req.params;
      const dto: CreateAttendanceDto = req.body;

      if (!dto.studentId || !dto.date || !dto.status) {
        return sendError(res, 400, "Missing required fields");
      }

      const teacher = await prisma.teacher.findUnique({
        where: { userId: req.user.id },
      });

      if (!teacher) {
        return sendError(res, 403, "Teacher not found");
      }

      const result = await teacherService.markAttendance(
        dto,
        teacher.id,
        classId
      );
      return sendSuccess(res, 201, "Attendance marked successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async giveGrade(req: Request, res: Response, next: NextFunction) {
    try {
      const { classId } = req.params;
      const dto: CreateGradeDto = req.body;

      if (!dto.studentId || !dto.subject || !dto.score) {
        return sendError(res, 400, "Missing required fields");
      }

      const teacher = await prisma.teacher.findUnique({
        where: { userId: req.user.id },
      });

      if (!teacher) {
        return sendError(res, 403, "Teacher not found");
      }

      const result = await teacherService.giveGrade(dto, teacher.id, classId);
      return sendSuccess(res, 201, "Grade given successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getClassStudents(req: Request, res: Response, next: NextFunction) {
    try {
      const { classId } = req.params;

      const teacher = await prisma.teacher.findUnique({
        where: { userId: req.user.id },
      });

      if (!teacher) {
        return sendError(res, 403, "Teacher not found");
      }

      const result = await teacherService.getClassStudents(classId, teacher.id);
      return sendSuccess(res, 200, "Students retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, error.statusCode || 400, error.message);
    }
  }

  async getClassAttendance(req: Request, res: Response, next: NextFunction) {
    try {
      const { classId } = req.params;

      const teacher = await prisma.teacher.findUnique({
        where: { userId: req.user.id },
      });

      if (!teacher) {
        return sendError(res, 403, "Teacher not found");
      }

      const result = await teacherService.getClassAttendance(
        classId,
        teacher.id
      );
      return sendSuccess(res, 200, "Attendance retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getClassGrades(req: Request, res: Response, next: NextFunction) {
    try {
      const { classId } = req.params;

      const teacher = await prisma.teacher.findUnique({
        where: { userId: req.user.id },
      });

      if (!teacher) {
        return sendError(res, 403, "Teacher not found");
      }

      const result = await teacherService.getClassGrades(classId, teacher.id);
      return sendSuccess(res, 200, "Grades retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }

  async getTeacherClasses(req: Request, res: Response, next: NextFunction) {
    try {
      const teacher = await prisma.teacher.findUnique({
        where: { userId: req.user.id },
      });

      if (!teacher) {
        return sendError(res, 403, "Teacher not found");
      }

      const result = await teacherService.getTeacherClasses(teacher.id);
      return sendSuccess(res, 200, "Classes retrieved successfully", result);
    } catch (error: any) {
      return sendError(res, 500, error.message);
    }
  }
}

export const teacherController = new TeacherController();
