import express, { Express, Request, Response, NextFunction } from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectDatabase, disconnectDatabase } from "./config/database";
import { errorHandler } from "./middleware/errorHandler";
import authRoutes from "./routes/authRoutes";
import superAdminRoutes from "./routes/superAdminRoutes";
import schoolAdminRoutes from "./routes/schoolAdminRoutes";
import teacherRoutes from "./routes/teacherRoutes";
import studentRoutes from "./routes/studentRoutes";
import prisma from "./config/database";
import { hashPassword } from "./utils/password";

dotenv.config();

const app: Express = express();
const PORT = process.env.PORT || 5000;
const CORS_ORIGIN = process.env.CORS_ORIGIN || "http://localhost:5173";

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  cors({
    origin: CORS_ORIGIN,
    credentials: true,
  })
);

// Request logging
app.use((req: Request, res: Response, next: NextFunction) => {
  console.log(`${req.method} ${req.path}`);
  next();
});

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/super-admin", superAdminRoutes);
app.use("/api/school-admin", schoolAdminRoutes);
app.use("/api/teacher", teacherRoutes);
app.use("/api/student", studentRoutes);

// Health check
app.get("/api/health", (req: Request, res: Response) => {
  res.status(200).json({
    success: true,
    message: "Server is running",
    timestamp: new Date().toISOString(),
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
    statusCode: 404,
  });
});

// Error handler
app.use(errorHandler);

// Initialize database and start server
const startServer = async () => {
  try {
    await connectDatabase();

    // Create super admin if not exists
    const superAdminExists = await prisma.user.findUnique({
      where: { username: "akhmad" },
    });

    if (!superAdminExists) {
      const passwordHash = await hashPassword("Suvonqulov2024");
      await prisma.user.create({
        data: {
          firstName: "Saidahmad",
          lastName: "Suvonqulov",
          email: "admin@maktab-ai.local",
          username: "akhmad",
          passwordHash,
          phoneNumber: "+998993327308",
          role: "SUPER_ADMIN",
          isActive: true,
        },
      });
      console.log("✅ Super admin created: akhmad / Suvonqulov2024");
    }

    const server = app.listen(PORT, () => {
      console.log(`
╔════════════════════════════════════════════════╗
║   🎓 MAKTAB AI - Educational Platform         ║
║   Backend Server Started Successfully          ║
║                                                ║
║   📍 Server: http://localhost:${PORT}          ║
║   🔐 Super Admin: akhmad / Suvonqulov2024     ║
║   📞 Founder: Saidahmad Suvonqulov            ║
║   ✉️  Email: akhmad@maktab-ai.local           ║
╚════════════════════════════════════════════════╝
      `);
    });

    // Graceful shutdown
    process.on("SIGTERM", async () => {
      console.log("SIGTERM received, shutting down gracefully");
      server.close(async () => {
        await disconnectDatabase();
        process.exit(0);
      });
    });

    process.on("SIGINT", async () => {
      console.log("SIGINT received, shutting down gracefully");
      server.close(async () => {
        await disconnectDatabase();
        process.exit(0);
      });
    });
  } catch (error) {
    console.error("❌ Server startup failed:", error);
    process.exit(1);
  }
};

startServer();
