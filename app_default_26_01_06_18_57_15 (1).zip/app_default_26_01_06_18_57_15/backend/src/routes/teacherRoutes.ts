import { Router } from "express";
import { teacherController } from "../controllers/teacherController";
import { authMiddleware } from "../middleware/auth";
import { roleGuard } from "../middleware/roleGuard";

const router = Router();

router.use(authMiddleware, roleGuard("TEACHER"));

router.post("/classes/:classId/attendance", (req, res, next) =>
  teacherController.markAttendance(req, res, next)
);

router.post("/classes/:classId/grades", (req, res, next) =>
  teacherController.giveGrade(req, res, next)
);

router.get("/classes/:classId/students", (req, res, next) =>
  teacherController.getClassStudents(req, res, next)
);

router.get("/classes/:classId/attendance", (req, res, next) =>
  teacherController.getClassAttendance(req, res, next)
);

router.get("/classes/:classId/grades", (req, res, next) =>
  teacherController.getClassGrades(req, res, next)
);

router.get("/classes", (req, res, next) =>
  teacherController.getTeacherClasses(req, res, next)
);

export default router;
