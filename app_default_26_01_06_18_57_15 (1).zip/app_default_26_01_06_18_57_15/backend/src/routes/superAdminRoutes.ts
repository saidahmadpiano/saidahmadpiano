import { Router } from "express";
import { superAdminController } from "../controllers/superAdminController";
import { authMiddleware } from "../middleware/auth";
import { roleGuard } from "../middleware/roleGuard";

const router = Router();

router.use(authMiddleware, roleGuard("SUPER_ADMIN"));

router.post("/schools", (req, res, next) =>
  superAdminController.createSchool(req, res, next)
);

router.get("/schools", (req, res, next) =>
  superAdminController.getAllSchools(req, res, next)
);

router.get("/schools/:schoolId", (req, res, next) =>
  superAdminController.getSchoolById(req, res, next)
);

router.put("/schools/:schoolId", (req, res, next) =>
  superAdminController.updateSchool(req, res, next)
);

router.delete("/schools/:schoolId", (req, res, next) =>
  superAdminController.deleteSchool(req, res, next)
);

router.get("/users", (req, res, next) =>
  superAdminController.getAllUsers(req, res, next)
);

router.get("/statistics", (req, res, next) =>
  superAdminController.getStatistics(req, res, next)
);

router.get("/audit-logs", (req, res, next) =>
  superAdminController.getAuditLogs(req, res, next)
);

export default router;
