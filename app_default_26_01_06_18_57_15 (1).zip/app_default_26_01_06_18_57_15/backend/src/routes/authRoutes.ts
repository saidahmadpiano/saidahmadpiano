import { Router } from "express";
import { authController } from "../controllers/authController";
import { authMiddleware } from "../middleware/auth";

const router = Router();

router.post("/login", (req, res, next) =>
  authController.login(req, res, next)
);

router.get("/verify", authMiddleware, (req, res, next) =>
  authController.verifyToken(req, res, next)
);

router.post("/logout", authMiddleware, (req, res, next) =>
  authController.logout(req, res, next)
);

export default router;
