import { Router } from "express";
import { studentController } from "../controllers/studentController";
import { authMiddleware } from "../middleware/auth";
import { roleGuard } from "../middleware/roleGuard";

const router = Router();

router.use(authMiddleware, roleGuard("STUDENT"));

router.get("/dashboard", (req, res, next) =>
  studentController.getDashboard(req, res, next)
);

router.get("/leaderboard", (req, res, next) =>
  studentController.getLeaderboard(req, res, next)
);

router.post("/focus-minutes", (req, res, next) =>
  studentController.updateFocusMinutes(req, res, next)
);

router.post("/ai-tutor", (req, res, next) =>
  studentController.getAiTutorResponse(req, res, next)
);

router.post("/snap-solve", (req, res, next) =>
  studentController.recordSnapSolve(req, res, next)
);

router.get("/career-prediction", (req, res, next) =>
  studentController.predictCareer(req, res, next)
);

export default router;
