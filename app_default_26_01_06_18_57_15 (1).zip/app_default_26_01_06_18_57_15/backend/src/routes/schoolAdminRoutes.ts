import { Router } from "express";
import { schoolAdminController } from "../controllers/schoolAdminController";
import { authMiddleware } from "../middleware/auth";
import { roleGuard } from "../middleware/roleGuard";

const router = Router();

router.use(authMiddleware, roleGuard("SCHOOL_ADMIN"));

router.post("/teachers", (req, res, next) =>
  schoolAdminController.createTeacher(req, res, next)
);

router.put("/teachers/:teacherId", (req, res, next) =>
  schoolAdminController.updateTeacher(req, res, next)
);

router.delete("/teachers/:teacherId", (req, res, next) =>
  schoolAdminController.deleteTeacher(req, res, next)
);

router.get("/teachers", (req, res, next) =>
  schoolAdminController.getTeachers(req, res, next)
);

router.post("/classes", (req, res, next) =>
  schoolAdminController.createClass(req, res, next)
);

router.get("/classes", (req, res, next) =>
  schoolAdminController.getClasses(req, res, next)
);

router.post("/classes/add-student", (req, res, next) =>
  schoolAdminController.addStudentToClass(req, res, next)
);

router.get("/statistics", (req, res, next) =>
  schoolAdminController.getStatistics(req, res, next)
);

export default router;
